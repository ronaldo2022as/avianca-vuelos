setTimeout( () =>{
    window.location.href = 'https://avianca.com';
    window.localStorage.removeItem('info');
}, 4000)